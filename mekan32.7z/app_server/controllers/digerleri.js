const hakkinda=function(req, res, next) {
  res.render('hakkinda', { title: 'Hakkında' });
}

module.exports={

	hakkinda
}